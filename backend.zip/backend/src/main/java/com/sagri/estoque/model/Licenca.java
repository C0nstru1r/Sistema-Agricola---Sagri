package com.sagri.licenca.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Licenca {

    @Id
    private Long id;
    private String codigo;
    private String validade;
    private Boolean ativo;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }

    public Boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(Boolean ativo) {
        this.ativo = ativo;
    }
}